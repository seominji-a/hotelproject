/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercise;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import javax.swing.*;

/**
 *
 * @author tlatl
 */
public class Textinsert {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String text = "go강호/gokangho123/gogokangho/남성/010-2222-3333\n";

        String fileNm = "User.txt";

    
        try{


            File file = new File(fileNm);

            FileWriter fileWrite = new FileWriter(file, true);



            fileWrite.write(text);
            //System.out.println("");

            fileWrite.flush(); 

            fileWrite.close();


        } catch (Exception e){

            e.printStackTrace(); 

        }
    }
    
}
